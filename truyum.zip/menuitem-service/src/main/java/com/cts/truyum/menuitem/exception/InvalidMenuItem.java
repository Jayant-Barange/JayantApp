package com.cts.truyum.menuitem.exception;

public class InvalidMenuItem extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InvalidMenuItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidMenuItem(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
