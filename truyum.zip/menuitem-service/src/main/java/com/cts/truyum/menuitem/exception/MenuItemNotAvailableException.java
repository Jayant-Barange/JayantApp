package com.cts.truyum.menuitem.exception;

public class MenuItemNotAvailableException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MenuItemNotAvailableException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MenuItemNotAvailableException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
