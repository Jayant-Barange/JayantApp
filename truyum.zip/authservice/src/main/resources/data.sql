insert into user (userid,upassword,uname) values ('admin','admin','admin');
insert into user (userid,upassword,uname) values ('admin1','admin1','admin1');