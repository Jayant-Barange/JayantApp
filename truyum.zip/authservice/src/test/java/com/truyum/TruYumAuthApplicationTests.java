package com.truyum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruYumAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
