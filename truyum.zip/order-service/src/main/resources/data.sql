insert into user(id,name) values(1,'harsh');
insert into user(id,name) values(2,'ankit');

insert into menu_item values(1, 1, 'Main Course', '2017-03-15', 1, 'Dal Rice', 99);
insert into menu_item values(2, 0, 'Main Course', '2017-12-23', 0, 'Pulao', 129);
insert into menu_item values(3, 1, 'Main Course', '2018-08-21', 0, 'Dal Bati', 149);
insert into menu_item values(4, 0, 'Starters', '2017-07-02', 0, 'French Fries', 57);
insert into menu_item values(5, 1, 'Dessert', '2022-11-02', 0, 'Chocolate brownie', 32);
insert into menu_item values(6, 1, 'Starters', '2017-03-17', 0, 'Cheese Balls', 99);
insert into menu_item values(7, 1, 'Dessert', '2017-12-10', 0, 'Rasgulla', 15);
insert into menu_item values(8, 0, 'Dessert', '2018-08-11', 0, 'Kajukatli', 600);
