package com.cts.truyum.order.exception;

public class MenuItemNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MenuItemNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MenuItemNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
